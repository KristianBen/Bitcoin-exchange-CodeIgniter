<?php
class Admin extends Controller{
	public function __construct () {
		parent::Controller();
		$this->load->helper(array('form', 'url'));
		$this->load->library('validation');
		
		$this->load->model('administration/Mod_authorisation');
		$flag = $this->Mod_authorisation->Varifyadmin();
		if($flag== FALSE)
		{ 
		   redirect('administration');
		}
	}
	
	public function index() {
		$data=array();
		$query=$this->db->get('country_tbl');
		$data['country_list']=$query;
		$msg=$this->uri->segment('4');
		if($msg)
		$data['msg']=$msg;

		$data['user']=$this->db->get_where('admin',array('previlage'=>'All'));
		  
		$this->load->view('administration/header');	
		$this->load->view('administration/admin_list',$data);
		$this->load->view('administration/footer');
	}

	public function add_new(){
		$data=array();
		$query=$this->db->get('country_tbl');
		$data['country_list']=$query;
		$this->load->view('administration/header');
		$this->load->view('administration/admin_resi',$data);	
		$this->load->view('administration/footer');		
	}

	public function check_email() {
		$this->load->library('form_validation');
		$email=$this->input->post("email");
		$query = $this->db->get_where('user', array('email' => $email));

		if ($query->num_rows()>0)
		{
		$this->validation->set_message('check_email', 'E-mail Address already exist');
			return FALSE;
		}
		else
		{
			return TRUE;
		}
	}

	public function check_email_edit() {
		$this->load->library('form_validation');
		$email=$this->input->post("email");
		$hid=$this->input->post("hid");

		$query = $this->db->get_where('user', array('email' => $email,'id !='=>$hid));

		if ($query->num_rows()>0)
		{
			$this->form_validation->set_message('callback_check_email', 'E-mail Address already exist');
			return FALSE;
		}
		else
		{
			return TRUE;
		}
	}


	public function add() {
		$data=array();
		//validation
		//end validation
		$query=$this->db->get('country_tbl');
		$data['country_list']=$query;
		if($this->input->post("submit"))
		{  
		$id=1;

		if($this->Mod_authorisation->update_admin($id)){
		$msg='Data Updated successfully';
		}
		$data['hid']=$id;	 
		redirect("administration/admin/index/$msg");
		exit;	 
	} 

		$data['user']=$this->db->get('admin');   
		$this->load->view('administration/header');
		$this->load->view('administration/admin_resi',$data);
		$this->load->view('administration/footer');
	}
	

	public function active() {
		$id=$this->uri->segment(4);	
		$update = array(
					   'status' =>'1'
					);
		$this->db->update('admin', $update, array('id' => $id));
		  
		$data=array();
		$query=$this->db->get('country_tbl');
		$data['country_list']=$query;
		$data['user']=$this->db->get_where('admin');
		  
		$this->load->view('administration/header');	
		$this->load->view('administration/admin_list',$data);
		$this->load->view('administration/footer');
	}


	public function inactive(){
		$id=$this->uri->segment(4);	
		$update = array(
		'status' =>'0'
		);
		$this->db->update('admin', $update, array('id' => $id));

		$data=array();
		$query=$this->db->get('country_tbl');
		$data['country_list']=$query;

		$data['user']=$this->db->get_where('admin');

		$this->load->view('administration/header');	
		$this->load->view('administration/admin_list',$data);
		$this->load->view('administration/footer');
   }


	public function viewpackage() {
		$adminid=$this->uri->segment(4);
		$category='';
		$data['admin']=$this->db->get_where('admin',array('id' =>$adminid));

		$this->load->view('administration/header');
		$this->load->view('administration/view_package',$data);
		$this->load->view('administration/footer');
	}	  
	  
	public function viewadmin() {
		$query=$this->db->get_where('admin',array('status' =>'1'));
		$data['admin_info']=$query;
		$this->load->view('administration/header');
		$this->load->view('administration/viewadmin',$data);
		$this->load->view('administration/footer');
	}
	
	public function paymentconfig() {
		$configdata = $this->db->get_where('mcp_payment_config', array('id' =>'1'))->row();
		$data['configdata'] = $configdata;
		$this->load->view('administration/header');	
		$this->load->view('administration/paymentconfig',$data);
		$this->load->view('administration/footer');
	}
}