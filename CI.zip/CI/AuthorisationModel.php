<?php
class AuthorisationModel extends Model {

    var $password   = '';
    var $email = '';
    var $date    = '';
	var $id = '';
	var $first_name = '';
	var $last_name = '';
	var $address = '';
	var $city = '';
	var $state = '';
	var $zip = '';
	var $suite = '';

    function __construct()
    {
        // Call the Model constructor
        parent::Model();
		
    }
    function do_login()
    {		
		$this->email   =$this->input->post('email');		
		$this->password = $this->input->post('password');
		$sql = "SELECT * FROM admin WHERE status='1' AND type='1' AND password = ? AND email = ?";
		$data = array(
		   'password' => md5($this->password),
			'email' => $this->email
		);
		$query = $this->db->query($sql, $data);		

		if($query->num_rows() > 0){
		$rs = $query->row();

		$data = array('adminid'=>$rs->id,'name'=>$rs->name,'access'=>$rs->access);	
		$this->session->set_userdata($data);
		 return $rs->id;   
		}else{
		return FALSE;
		}
    } 
   
	function Varifyadmin(){
		$adminid='';
		$adminid = $this->session->userdata('adminid');

		if($adminid < 1){
			$flag = FALSE;
		} else {
			$sql = "SELECT * FROM admin WHERE id = ?";
			$data = array('id' => $adminid);
			$query = $this->db->query($sql, $data);		
			if($query->num_rows() > 0){
			$rs = $query->row();
			$flag =($rs->type == 1)?TRUE:FALSE;	
			} else {
			   return false;
			}
		}
		return $flag;								
	}// end VarifyAdmin	

	function get_chr_pos($pos,$ch)
	{
		$query = $this->db->get('memory');
		if($query->num_rows() > 0){
			$word_info=$query->row();
			$word=$word_info->memory_word;

			if($ch==$word{$pos-1})
			 return true;
		}
		return false;
	}

    function update_admin($id) {
        $fname=$this->input->post("fname");
		$lname=$this->input->post("lname");
		$email=$this->input->post("email");
		$pass=MD5($this->input->post("password"));
		$country_code=$this->input->post("country_name");
		$cell=$this->input->post("cell");
		$ptime=time(); 
		$data = array(
				   'first_name' =>$fname,
				   'last_name' =>$lname ,
				   'country_code' =>$country_code,
				   'mobile' =>$cell,
				   'email' =>$email,
				   'password' =>$pass
					   
				);

		$this->db->where('id', $id);
		if($this->db->update('admin', $data))
		return true;
	}


	function update_publisher($id)
	{
		$fname=$this->input->post("fname");
		$lname=$this->input->post("lname");
		$email=$this->input->post("email");
		$pass=MD5($this->input->post("password"));
		$country_code=$this->input->post("country_name");
		$cell=$this->input->post("cell");
		$ptime=time();
		$data = array(
				   'first_name' =>$fname,
				   'last_name' =>$lname ,
				   'country_code' =>$country_code,
				   'mobile' =>$cell,
				   'email' =>$email,
				   'password' =>$pass
					   
				);

		$this->db->where('id', $id);
		$this->db->update('publisher', $data); 


		//update category user.

		$this->db->order_by("category_id", "Asc");
		$query=$this->db->get('category');
		$pcat='';
		foreach($query->result() as $row)
		{
			$temp=$this->input->post("chk".$row->category_id);	  
			if($temp=='on')
			{
				$pcat.=$row->category_id;
				$pcat.="|";
			}
		}
		$data = array(
				   'category_id' =>$pcat
					);

		$this->db->where('publisher_id', $id);
		$this->db->update('category_user', $data); 
		
	}
}

?>